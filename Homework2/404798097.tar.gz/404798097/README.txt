Chayanis Techalertumpai, 404798097, furncyn@ucla.edu
Connie Chen, 904920137, conniechenn21@ucla.edu


Resources used to complete the project:
Task 2.1 - 2.3
  - https://www.geeksforgeeks.org/python-program-extract-frames-using-opencv/
Task 2.4
  - https://scikit-image.org/docs/dev/auto_examples/features_detection/plot_template.html
Task 2.5
  - https://docs.opencv.org/2.4/modules/imgproc/doc/geometric_transformations.html?highlight=warpaffine
